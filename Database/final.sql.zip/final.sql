--
-- Database: `final`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `currentbal` decimal(10,0) NOT NULL,
  `username` varchar(255) NOT NULL,
  `month` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `currentbal`, `username`, `month`) VALUES
(6, '130', 'joy', 'April'),
(7, '505', 'pro', 'April'),
(8, '955', 'sk', 'April');

-- --------------------------------------------------------

--
-- Table structure for table `catagory`
--

CREATE TABLE `catagory` (
  `id` int(11) NOT NULL,
  `catagory` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `catagory`
--

INSERT INTO `catagory` (`id`, `catagory`) VALUES
(1, 'Food'),
(2, 'Drink'),
(3, 'Internet'),
(4, 'Phone Bill'),
(5, 'Education'),
(6, 'Vehicle'),
(7, 'Shopping'),
(8, 'Entertainment'),
(11, ''),
(12, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `cost`
--

CREATE TABLE `cost` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `catagory` varchar(20) NOT NULL,
  `cost` int(11) NOT NULL,
  `date` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP
) ;

--
-- Dumping data for table `cost`
--

INSERT INTO `cost` (`id`, `username`, `catagory`, `cost`, `date`) VALUES
(1, 'joy', 'Food', 100, '2017-04-17 17:38:08.000000'),
(2, 'joy', 'Education', 50, '2017-04-17 17:45:49.000000'),
(3, 'pro', 'Food', 45, '2017-04-17 17:48:00.000000'),
(4, 'pro', 'Vehicle', 50, '2017-04-17 21:55:19.000000'),
(5, 'sk', 'Vehicle', 45, '2017-04-23 18:29:54.000000'),
(6, 'joy', 'Shopping', 200, '2017-04-26 12:45:14.000000');

-- --------------------------------------------------------

--
-- Table structure for table `monthtable`
--

CREATE TABLE `monthtable` (
  `id` int(11) NOT NULL,
  `month` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `monthtable`
--

INSERT INTO `monthtable` (`id`, `month`) VALUES
(1, 'January'),
(2, 'February'),
(3, 'March'),
(4, 'April'),
(5, 'May'),
(6, 'June'),
(7, 'July'),
(8, 'August'),
(9, 'September'),
(10, 'October'),
(11, 'November'),
(12, 'December');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `name`, `username`, `password`, `email`, `mobile`) VALUES
(1, 'Joy ', 'joy', 'pass', 'joyd451@gmail.com', '+8801831586368'),
(2, 'Prothom', 'pro', '12345', 'prothom@gmail.com', '4545454'),
(3, 'Sourav', 'sk', '123', 'email', '45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catagory`
--
ALTER TABLE `catagory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `monthtable`
--
ALTER TABLE `monthtable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `catagory`
--
ALTER TABLE `catagory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `cost`
--
ALTER TABLE `cost`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
